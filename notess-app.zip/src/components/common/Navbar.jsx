import React from "react";

const Navbar = () => {
  return (
    <>
      <div className="bg-black uppercase text-4xl py-3 text-white font-medium px-5">
        NOTES
      </div>
    </>
  );
};

export default Navbar;
